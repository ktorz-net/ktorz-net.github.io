#!env python3
import json, sys
import hacka.games.moveit as moveit
from hacka.games.moveit.player import ShellPlayer as Opponent
from bot import VoidBot as Bot

print( "Start: " + " ".join(sys.argv) )

config= {
    "matrix": [
        [ 0,  0,  0,  0],
        [ 0, -1,  0, -1],
        [ 0,  0,  0,  0]
    ],
    "tic": 10,
    "numberOfMissions": 2,
    "numberOfPlayers": 1,
    "numberOfRobots": 1,
    "numberOfPVips": 1,
    "vipZones": [1, 4, 7, 10]
}

# Open a configuration file:
nbArgs= len(sys.argv)
if nbArgs > 1 :
    with open( sys.argv[1] ) as file:
        config= json.load(file)

# number of player:
if nbArgs > 2 :
    config["numberOfPlayers"]= int(sys.argv[2])

# number of robot:
if nbArgs > 3 :
    config["numberOfRobots"]= int(sys.argv[3])

# VIP:
if nbArgs > 4 :
    config["numberOfPVips"]= max( int(sys.argv[4]), 1 )

# Configure the game:
gameEngine= moveit.GameEngine(
    matrix= config['matrix'],
    tic= config['tic'],
    numberOfPlayers= config['numberOfPlayers'], numberOfRobots= config['numberOfRobots'],
    numberOfPVips= config['numberOfPVips']
)

# Then Go...
gameMaster= moveit.GameMaster( gameEngine, randomMission= config['numberOfMissions'], vipZones= [1])
player1= Bot()
player2= Opponent()

if config['numberOfPlayers'] == 2 :
    gameMaster.launch( [player1, player2] )
else :
    gameMaster.launch( [player1] )
