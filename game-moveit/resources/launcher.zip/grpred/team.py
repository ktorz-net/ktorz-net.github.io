from . import bot

def bots(): 
    return [ bot.VoidBot("A"), bot.VoidBot("B") ]
