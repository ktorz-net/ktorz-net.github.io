#!python3

# get resourses:
from hacka.games.py421 import GameSolo as Game

## Policy :
# import py421PiBots as bots
# bot = bots.RecorderBot()
# bot = bots.RecorderBot(bots.Pi421Load("./dico-py421policy.json"))

## Learning :
import py421pool as bots

# bot = bots.RBot()
# bot = bots.QBot()
# bot = bots.TBot()
bot = bots.MBot()

# Setup a game and a bot:
game = Game()

# run XX games
xx = 50000
results = game.launch([bot], xx)

# Analyze the result
print(f"Average score: {sum(results[0]) / xx}")
