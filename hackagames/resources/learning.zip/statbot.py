import matplotlib.pyplot as plt
import os, json, random

class Bot:
    def __init__(self, name="Last"):
        # Process monitoring:
        self._name = name
        self._results = []
        self._stats = {self._name: []}
        self._benchSize = 500
        self.loadEvals()

    # Get Some
    def loadEvals(self):
        filePath = f"log-stats_{self._benchSize}.json"
        curentStats = self._stats[self._name]
        # get other results:
        if os.path.isfile(filePath):
            with open(filePath) as fileContent:
                self._stats = json.load(fileContent)
                fileContent.close()
        self._stats[self._name] = curentStats

    def dumpEvals(self):
        filePath = f"log-stats_{self._benchSize}.json"
        fileContent = open(filePath, "w")
        json.dump(self._stats, fileContent, sort_keys=True, indent=2)
        fileContent.close()

    def sleep(self, result):
        self._results.append(result)
        if len(self._results) == self._benchSize:
            self.updateBench()
            self._stats[self._name].append(sum(self._results) / self._benchSize)
            self._results = []
            if len(self._stats[self._name]) % 2 == 0:
                self.drawEvaluations()
                self.dumpEvals()

    def drawEvaluations(self):
        colors = ["green", "red", "orange", "black", "blue"]
        iColor = 0
        for entrance in self._stats:
            seri = self._stats[entrance]
            color = colors[iColor]
            iColor = (iColor + 1) % len(colors)
            plt.plot(
                [i * self._benchSize for i in range(len(seri))],
                seri,
                color=color,
                label=entrance,
            )
            lastAverage = sum(seri[-10:]) / 10
            plt.plot(
                [0, len(seri) * self._benchSize],
                [lastAverage, lastAverage],
                color=(color, 0.2),
                ls="-.",
            )
        plt.legend(loc="best")
        plt.savefig("output.png")
        plt.clf()

    def updateBench(self):
        pass
