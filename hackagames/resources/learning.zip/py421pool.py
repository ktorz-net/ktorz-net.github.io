import random, json, statbot


#       Random Bot       :
# -------------------------
class RBot(statbot.Bot):
    def __init__(self):
        super().__init__("Random")

    # Player interface :
    def wakeUp(self, playerId, numberOfPlayers, gameConf):
        self._state = "wakeUp"
        self._action = "roll-roll-roll"
        self._score = 0

    def perceive(self, gameState):
        self._horizon = gameState.child(1).integer(1)
        self._dices = gameState.child(2).integers()
        self._score = gameState.child(2).value(1)

    def decide(self):
        self._action = random.choice(
            [
                "keep-keep-keep",
                "roll-keep-keep",
                "keep-roll-keep",
                "roll-roll-keep",
                "keep-keep-roll",
                "roll-keep-roll",
                "keep-roll-roll",
                "roll-roll-roll",
            ]
        )
        return self._action


#       QLearning Bot       :
# ----------------------------
class QBot(statbot.Bot):
    def __init__(self, name="QLearning", alpha=0.1, epGreedy=0.1):
        super().__init__(name)
        # Q-Learning attributes:
        self._alpha = alpha
        self._epsilon = epGreedy
        # Q-Learning dictionary:
        self._qvalues = {"wakeUp": {"roll-roll-roll": 0.0}}

    # Model:
    def state(self):
        # format game configuration as a qvalues dictionary string entrance:
        polution = ""
        # polution= random.choice([ "-A", "-B", "-C", "-D" ])
        return f"{self._horizon}-{self._dices[0]}-{self._dices[1]}-{self._dices[2]}{polution}"

    def updateTransition(self, previous_state, action, current_state, reward):
        # Update Qvalues dictionary with an experience:
        if current_state not in self._qvalues:
            self._qvalues[current_state] = {
                "keep-keep-keep": 0.0,
                "roll-keep-keep": 0.0,
                "keep-roll-keep": 0.0,
                "roll-roll-keep": 0.0,
                "keep-keep-roll": 0.0,
                "roll-keep-roll": 0.0,
                "keep-roll-roll": 0.0,
                "roll-roll-roll": 0.0,
            }
        oldValue = self._qvalues[previous_state][action]
        expValue = reward + max(self._qvalues[current_state].values())
        self._qvalues[previous_state][action] = (
            1 - self._alpha
        ) * oldValue + self._alpha * expValue
        return self._qvalues[previous_state][action]

    # Player interface :
    def wakeUp(self, playerId, numberOfPlayers, gameConf):
        self._state = "wakeUp"
        self._action = "roll-roll-roll"
        self._score = 0

    def perceive(self, gameState):
        self._horizon = gameState.child(1).integer(1)
        self._dices = gameState.child(2).integers()
        newScore = gameState.child(2).value(1)
        # Learn:
        newState = self.state()
        self.updateTransition(
            self._state, self._action, newState, newScore - self._score
        )
        # Switch:
        self._state = newState
        self._score = newScore

    def decide(self):
        if random.random() > self._epsilon and self._state in self._qvalues:
            self._action = list(self._qvalues[self._state].keys())[0]
            for action in self._qvalues[self._state]:
                if (
                    self._qvalues[self._state][action]
                    > self._qvalues[self._state][self._action]
                ):
                    self._action = action
        else:
            self._action = random.choice(list(self._qvalues[self._state].keys()))
        return self._action

    def updateBench(self):
        # Dump qvalues:
        modelFile = open("qvalues.json", "w")
        json.dump(self._qvalues, modelFile, sort_keys=True, indent=2)
        modelFile.close()
        # Reduce learning parameters:
        # self._epsilon = max(self._epsilon - 0.01, 0.01)
        # self._alpha = max(self._alpha - 0.0005, 0.001)


#       Tree based QBot       :
# ------------------------------
class TBot(QBot):
    def __init__(self, name="Tree-QL"):
        super().__init__(name)

    def state(self):
        # format game configuration as a qvalues dictionary string entrance:
        if self._horizon == 0:
            return "end"
        if self._dices[2] == 1:
            if self._dices[1] == 2:
                if self._dices[0] == 4:
                    return "X|4-2-1"
                return "X|X-2-1"
            if self._dices[1] == 1:
                if self._dices[0] == 1:
                    return "X|1-1-1"
                return "X|X-1-1"
            return "X|X-X-1"
        return "nothing"


#       Model-Based Bot       :
# ------------------------------
class MBot(QBot):
    def __init__(self, name="Model-Based"):
        super().__init__(name)
        self._epsilon = 0.2
        # Model:
        self._experiements = {}
        self._transitions = {}
        self._rewards = {}
        # Solving:
        self._policy = {}
        self._values = {}

    def updateTransition(self, previous_state, action, current_state, reward):
        # Update Structure:
        if previous_state not in self._experiements:
            self._experiements[previous_state] = {"k-k-k": 0}
            self._transitions[previous_state] = {"k-k-k": {}}
            self._rewards[previous_state] = {"k-k-k": 0}

        if action not in self._experiements[previous_state]:
            self._experiements[previous_state][action] = 0
            self._transitions[previous_state][action] = {current_state: 0}
            self._rewards[previous_state][action] = 0

        if current_state not in self._transitions[previous_state][action]:
            self._transitions[previous_state][action][current_state] = 0

        # Update Values:
        self._experiements[previous_state][action] += 1
        self._transitions[previous_state][action][current_state] += 1
        exp = self._experiements[previous_state][action]
        oldReward = self._rewards[previous_state][action] * (exp - 1)
        self._rewards[previous_state][action] = (oldReward + reward) / exp

    # Player interface :
    def decide(self):
        actions = [
            "r-r-r",
            "k-r-r",
            "r-k-r",
            "k-k-r",
            "r-r-k",
            "k-r-k",
            "r-k-k",
            "k-k-k",
        ]
        if random.random() > self._epsilon and self._state in self._policy:
            self._action = self._policy[self._state]
        else:
            self._action = random.choice(actions)
        return self._action

    def updateBench(self):
        # Update policy:
        self._policy, self._values = self.valueIteration(0.001)
        # Dump model:
        modelFile = open("model.json", "w")
        json.dump(
            {"T": self._transitions, "R": self._rewards},
            modelFile,
            sort_keys=True,
            indent=2,
        )
        modelFile.close()
        # Dump policy:
        modelFile = open("policy.json", "w")
        json.dump(
            {"P": self._policy, "V": self._values}, modelFile, sort_keys=True, indent=2
        )
        modelFile.close()
        # Reduce epsilon greedy:
        self._epsilon = max(self._epsilon - 0.01, 0.0001)

    # Solving:
    def belman(self, state, action, values):
        value = 0.0
        exps = self._experiements[state][action]
        for future in self._transitions[state][action]:
            if future in values:
                value += (self._transitions[state][action][future] / exps) * values[
                    future
                ]
        return value + self._rewards[state][action]

    def bestAction(self, state, values):
        actions = list(self._transitions[state].keys())
        maxValue = self.belman(state, actions[0], values)
        bestAction = actions[0]
        for action in actions[1:]:
            value = self.belman(state, action, values)
            if value > maxValue:
                maxValue = value
                bestAction = action
        return bestAction, maxValue

    def valueIteration(self, epsilon):
        policy = {state: "k-k-k" for state in self._experiements}
        values = {state: 0.0 for state in self._experiements}
        maxDelta = 1 + epsilon
        while maxDelta > epsilon:
            maxDelta = 0.0
            for state in self._experiements:
                action, value = self.bestAction(state, values)
                # Update delta:
                delta = abs(value - values[state])
                if delta > maxDelta:
                    maxDelta = delta
                # Update Policy and Values:
                policy[state] = action
                values[state] = value
        return policy, values


# class PiBot(QBot):
