import random, json, statbot

#       Recorder Bot       :
#---------------------------
class Pi421Random():
    def process(self, state):
        return random.choice( [
                "keep-keep-keep", "roll-keep-keep", "keep-roll-keep", "roll-roll-keep", 
                "keep-keep-roll", "roll-keep-roll", "keep-roll-roll", "roll-roll-roll" ] )

class Pi421Load():
    def __init__(self, file ):
        policyFile= open(file)
        self._piDico= json.load( policyFile )
        policyFile.close()

    def process(self, state):
        if state in self._piDico :
            return self._piDico[state]
        print("at random")
        return random.choice( [
                "keep-keep-keep", "roll-keep-keep", "keep-roll-keep", "roll-roll-keep", 
                "keep-keep-roll", "roll-keep-roll", "keep-roll-roll", "roll-roll-roll" ] )

class RecorderBot():
    def __init__(self, policy= Pi421Random() ):
        self._pi= policy

    def wakeUp(self, playerId, numberOfPlayers, gameConf):
        # Recorder buffer: 
        self._trace= []

    def perceive(self, gameState):
        # Game variables:
        self._horizon = gameState.child(1).integer(1)
        self._dices = gameState.child(2).integers()
        self._score = gameState.child(2).value(1)

    def decide(self):
        state= '-'.join([ str(d) for d in self._dices ])
        state+= f"({self._horizon})"
        action= self._pi.process(state)
        self._trace.append( {'state': state, 'action': action} )
        return action

    def sleep(self, result):
        # open a State.Action.Value file in append mode:
        logFile= open( "log-SAV.csv", "a" ) 
        # For each recorded experience in trace
        for xp in self._trace :
            # add a line in the file
            logFile.write( f"{xp['state']}, {xp['action']}, {result}\n" )
        logFile.close()

