#!python3
import json

data= {}

# Load data..
logFile= open("log-SAV.csv", "r")
for line in logFile :
    state, action, value= tuple( line.split(', ') )
    value= float(value)
    if state not in data :
        data[state]= {action: [value]}
    elif action not in data[state]:
        data[state][action]= [value]
    else :
        data[state][action].append( value )
logFile.close()

computedPolicy= {}
for state in data:
    print( f"\n{state}" )
    bestAction= False 
    for action in data[state]:
        print( f"- {action}: {data[state][action]}" )
        value= sum(data[state][action]) / len(data[state][action])
        print( f"\t: {value}" )
        if (not bestAction) or value > bestValue: 
            bestAction= action
            bestValue= value
    print( f"best: {bestAction}")
    computedPolicy[state]= bestAction

policyFile= open("dico-py421policy.json", "w")
json.dump( computedPolicy, policyFile, sort_keys=True, indent=2 )
policyFile.close()

